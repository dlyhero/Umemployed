import { sideBar } from "./resume.js";
import { setupBackdropMenu } from "./resume.js";

setupBackdropMenu();
sideBar();